
//navigation bar

const hamburger = document.querySelector('.hamburger');
const navbar = document.querySelector('.navbar');

hamburger.addEventListener('click', () => {
    navbar.classList.toggle('active');
    hamburger.classList.toggle('active'); 
});
		


 // function to do google search
    function performSearch() {
        const query = searchInput.value;
            if (query) {
                const searchURL = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
                window.location.href = searchURL;
            }
        }
		
	
 // function to do voice search
        
const voiceSearchBtn = document.getElementById('voice-search-btn');
const searchInput = document.getElementById('search-input');
const searchBtn = document.getElementById('search-btn');

voiceSearchBtn.addEventListener('click', () => {
const recognition = new webkitSpeechRecognition() || new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.onresult = function(event) {
const query = event.results[0][0].transcript;
    searchInput.value = query; 
};

    recognition.onend = function() {
    performSearch();
};

    recognition.start();
        
});

        
searchBtn.addEventListener('click', performSearch);

       

  